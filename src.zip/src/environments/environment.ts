
export const environment = {
  production: false,
  tokenType: "Bearer ",
  accessToken:
    "BQAJ_AebdDCpscHcTkyXtmKKBzyPK8xFvJPOzpApurfnaHhguAsDdpF4p1WX7tgo2ZhmDjRwDWZCTDacpR0ebfooXb2WS9ubwATQhVewvtQq6oPvnmEgbB1llz94QN7SX5s-0qHLzlHXTQEwr9068UGdZlJtSHvgEbk",
  baseUrl: "https://api.spotify.com/v1/"
};

